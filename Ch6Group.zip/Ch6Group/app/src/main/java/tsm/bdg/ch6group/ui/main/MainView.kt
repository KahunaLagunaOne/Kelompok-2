package  tsm.bdg.ch6group.ui.main

interface MainView {
    fun showResult (result: String)
}