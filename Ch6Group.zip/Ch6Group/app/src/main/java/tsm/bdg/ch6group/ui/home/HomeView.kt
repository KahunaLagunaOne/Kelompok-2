package tsm.bdg.ch6group.ui.home

interface HomeView {
    fun onMenu()
}