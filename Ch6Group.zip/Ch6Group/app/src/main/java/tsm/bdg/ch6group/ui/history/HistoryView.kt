package tsm.bdg.ch6group.ui.history

interface HistoryView {
    fun showHistory()
}