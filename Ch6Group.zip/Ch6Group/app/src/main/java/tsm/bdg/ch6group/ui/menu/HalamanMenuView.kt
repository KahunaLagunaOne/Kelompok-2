package tsm.bdg.ch6group.ui.menu

interface HalamanMenuView {
    fun onPlayer()
    fun onCPU()
}